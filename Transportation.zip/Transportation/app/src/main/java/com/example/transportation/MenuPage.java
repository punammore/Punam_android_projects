package com.example.transportation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MenuPage extends AppCompatActivity {
    Button btnAdd,btnSearch,btnViewMyTour,btnViewTour;
    String Uid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu_page);
        btnAdd=findViewById(R.id.btnAdd);
        btnSearch=findViewById(R.id.btnSearch);
        btnViewMyTour=findViewById(R.id.btnViewMyTour);
        btnViewTour=findViewById(R.id.btnViewTour);
        Uid=getIntent().getExtras().getInt("Uid")+"";
      //  Toast.makeText(MenuPage.this, "Uid1="+ Uid, Toast.LENGTH_SHORT).show();
        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuPage.this,SearchTour.class).putExtra("Uid",Uid+""));


            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuPage.this,AddNewTour.class).putExtra("Uid",Uid));

            }
        });
        btnViewMyTour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuPage.this,ViewMyTour.class).putExtra("Uid",Uid));

            }
        });

        btnViewTour.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MenuPage.this,ViewTour.class).putExtra("Uid",Uid));

            }
        });
    }
}
