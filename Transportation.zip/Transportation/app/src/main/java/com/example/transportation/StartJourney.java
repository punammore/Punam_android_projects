package com.example.transportation;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class StartJourney extends AppCompatActivity {
    Button btnStartJourney;
    String Tid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_journey);
        btnStartJourney=findViewById(R.id.btnStartJourney);
        Tid=getIntent().getExtras().getString("id");


        btnStartJourney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //btnStartJourney.setText("Stop Journey");

                startActivity(new Intent(StartJourney.this,MapsActivity2.class).putExtra("Tid",Tid));

            }
        });
    }
}
