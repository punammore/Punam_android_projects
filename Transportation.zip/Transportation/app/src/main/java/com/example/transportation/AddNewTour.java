package com.example.transportation;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class AddNewTour extends AppCompatActivity {

    EditText edtFrom,edtTo,edtRate,edtWeight,edtArrival,edtDeparture,edtComment,edtDte,edtVehicleNo;
    Button btnSubmit;
    String Uid;


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_new_tour);
        edtFrom=findViewById(R.id.edtFrom);
        edtTo=findViewById(R.id.edtTo);
        edtRate=findViewById(R.id.edtRate);
        edtWeight=findViewById(R.id.edtWeight);
        edtArrival=findViewById(R.id.edtArrival);
        edtDeparture=findViewById(R.id.edtDeparture);
        edtComment=findViewById(R.id.edtComment);
        edtDte=findViewById(R.id.edtDte);
        edtVehicleNo=findViewById(R.id.edtVehicleNo);
        btnSubmit=findViewById(R.id.btnSubmit);
        Uid=getIntent().getExtras().getString("Uid");
        Toast.makeText(AddNewTour.this, "Uid"+ Uid, Toast.LENGTH_SHORT).show();

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MyTaskOld().execute();

            }

        });
    }
    class MyTaskOld extends AsyncTask {

        ProgressDialog pDialog = null;

        String FromLocation,ToLocation,Rate,Weight,ArrivalTime,DepartureTime,Comments,TourDte,VehicleNo;

        StringBuilder sb=null;

        String sql;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(AddNewTour.this);
            pDialog.setMessage("Fetching Data...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            FromLocation = edtFrom.getText().toString();
            ToLocation = edtTo.getText().toString();
            Rate = edtRate.getText().toString();
            Weight = edtWeight.getText().toString() + "Kg";
            ArrivalTime = edtArrival.getText().toString();
            DepartureTime = edtDeparture.getText().toString();
            TourDte=edtDte.getText().toString();
            VehicleNo=edtVehicleNo.getText().toString();
            Comments= edtComment.getText().toString();

            sql = getResources().getString(R.string.ip) + "/trans/insert_Tour.php?FromLocation="+FromLocation + "&ToLocation="+ToLocation + "&MaxWeight="+Weight + "&Rate=" + Rate + "&DepartureTime=" + DepartureTime + "&ArrivalTime=" + ArrivalTime + "&Date=" + TourDte + "&Comments=" + Comments + "&Uid=" + Uid +"&VechileNo=" +VehicleNo;

            Toast.makeText(AddNewTour.this, "Sql: " + sql, Toast.LENGTH_SHORT).show();
        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL(sql);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();

            Toast.makeText(AddNewTour.this, ""+sb.toString(), Toast.LENGTH_LONG).show();
        }
    }

}

