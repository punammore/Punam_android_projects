package com.example.transportation;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserPage extends AppCompatActivity {

    Button btnLogin, btnSignUp;

    EditText edtEmail,edtPwd;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_user_page);

        btnSignUp = findViewById(R.id.btnSignUp);
        btnLogin = findViewById(R.id.btnLogin);
        edtEmail=findViewById(R.id.edtEmail);
        edtPwd=findViewById(R.id.edtPwd);

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(UserPage.this,UserRegistration.class));
            }
        });

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new MyTaskOld().execute();

            }
        });

    }



    class MyTaskOld extends AsyncTask{

        ProgressDialog pDialog = null;

        String email,pwd;

        StringBuilder sb=null;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(UserPage.this);
            pDialog.setMessage("Fetching Data...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            email= edtEmail.getText().toString();
            pwd= edtPwd.getText().toString();

        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL(getResources().getString(R.string.ip) + "/trans/verify_login.php?email="+email + "&password="+pwd);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();

            int output = Integer.parseInt(sb.toString().trim());
            if(output>0)
            {
                startActivity(new Intent(UserPage.this,MenuPage.class).putExtra("Uid",output));
                Toast.makeText(UserPage.this, "Login Successful"+ output, Toast.LENGTH_SHORT).show();
            }
            else
            {
                Toast.makeText(UserPage.this, "email or password Missmatch", Toast.LENGTH_SHORT).show();
            }

           // Toast.makeText(UserPage.this, ""+sb.toString(), Toast.LENGTH_LONG).show();
        }
    }



}


