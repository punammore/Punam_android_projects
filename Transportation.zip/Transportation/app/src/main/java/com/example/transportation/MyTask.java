package com.example.transportation;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

class MyTask extends AsyncTask {

    ProgressDialog pDialog = null;

    String result;
    String s_url = "";
    Context cx;
    StringBuilder sb=null;

   public  MyTask(String url, Context cx)
    {
        this.s_url = url;
        this.cx = cx;
    }

    @Override
    protected void onPreExecute() {
        super.onPreExecute();

        pDialog = new ProgressDialog(cx);
        pDialog.setMessage("Fetching Data...");
        pDialog.setCancelable(false);
        pDialog.setIndeterminate(false);
        pDialog.show();


    }

    @Override
    protected Object doInBackground(Object[] objects) {


        BufferedReader reader=null;
        String serverResponse=null;
        try {

            URL url = new URL(s_url);
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

            connection.connect();
            int statusCode = connection.getResponseCode();
            //Log.e("statusCode", "" + statusCode);
            if (statusCode == 200) {
                sb = new StringBuilder();
                reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                String line;
                while ((line = reader.readLine()) != null) {
                    sb.append(line + "\n");
                }
            }

            connection.disconnect();
            if (sb!=null)
                serverResponse=sb.toString();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (reader != null) {
                try {
                    reader.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }




        return null;
    }

    @Override
    protected void onPostExecute(Object o) {
        super.onPostExecute(o);

        pDialog.dismiss();

        //Toast.makeText(MyTask.this, ""+sb.toString(), Toast.LENGTH_LONG).show();
    }

    public String getResponse()
    {
        return  sb.toString();
    }
}