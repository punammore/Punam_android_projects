package com.example.transportation;

import android.os.AsyncTask;
import android.os.Bundle;
import android.widget.TextView;

import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

import java.io.BufferedInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class TrackVehicle extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    TextView txtDepart,txtArr;

    String Tid="";
    String ip="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_track_vehicle);



        Tid = getIntent().getExtras().getString("Tid");

        ip = getResources().getString(R.string.ip);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);


    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        new FetchLongiLati().execute();

    }

    class FetchLongiLati extends AsyncTask
    {
        String s;




        @Override
        protected void onPreExecute() {
            super.onPreExecute();
            s="";
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            s=s.substring(0,s.length()-1);
            String[] tmp=s.split(";");


//            Toast.makeText(MapsActivity.this, "Dept:"+tmp[2] + "  Arr:" + tmp[3], Toast.LENGTH_SHORT).show();

          //  txtArr.setText("Arrival:" + tmp[3]);
           // txtDepart.setText("Depart:" + tmp[2]);

            //Toast.makeText(MapsActivity.this, "S="+s, Toast.LENGTH_SHORT).show();

            // Add a marker in Sydney and move the camera
            LatLng sydney = new LatLng(Double.parseDouble(tmp[1]),Double.parseDouble(tmp[0]));

            mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
            mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
            mMap.animateCamera(CameraUpdateFactory.zoomTo(15));


        }

        @Override
        protected Object doInBackground(Object[] params) {
            try {


                URL url = new URL( ip + "/trans/fetch_longi_latti.php?Tid="+Tid);

                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                InputStream in = new BufferedInputStream(urlConnection.getInputStream());
                int c;
                do {
                    c = in.read();
                    if (c == '\n')
                        break;
                    s += (char) c + "";
                } while (c != -1);
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            return null;


        }
    }
}
