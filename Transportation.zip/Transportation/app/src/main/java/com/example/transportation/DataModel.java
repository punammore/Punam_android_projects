package com.example.transportation;

public class DataModel {
String VehicleNo,Rate,Weight,Date,ArrivalTime,DepartureTime,Id;

    public DataModel(String vehicleNo, String rate, String weight, String date, String arrivalTime, String departureTime,String id) {
        VehicleNo = vehicleNo;
        Rate = rate;
        Weight = weight;
        Date = date;
        ArrivalTime = arrivalTime;
        DepartureTime = departureTime;
        Id =id;


    }

    public String getVehicleNo() {
        return VehicleNo;
    }

    public void setVehicleNo(String vehicleNo) {
        VehicleNo = vehicleNo;
    }

    public String getRate() {
        return Rate;
    }

    public void setRate(String rate) {
        Rate = rate;
    }

    public String getWeight() {
        return Weight;
    }

    public void setWeight(String weight) {
        Weight = weight;
    }

    public String getDate() {
        return Date;
    }

    public void setDate(String date) {
        Date = date;
    }

    public String getArrivalTime() {
        return ArrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        ArrivalTime = arrivalTime;
    }

    public String getDepartureTime() {
        return DepartureTime;
    }

    public void setDepartureTime(String departureTime) {
        DepartureTime = departureTime;

    }

    public String getId() {
        return Id;
    }
}



