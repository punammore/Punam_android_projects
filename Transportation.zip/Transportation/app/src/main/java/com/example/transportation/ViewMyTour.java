package com.example.transportation;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class ViewMyTour extends AppCompatActivity {
    String Uid;

    ArrayList<DataModel> dataModels;
    ListView listView;
    CustomAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_my_tour);

        listView=findViewById(R.id.edtList);

        Uid=getIntent().getExtras().getString("Uid");
       // Toast.makeText(this, ""+Uid, Toast.LENGTH_SHORT).show();

        dataModels= new ArrayList<>();

        new  MyTaskOld().execute();
    }


    class MyTaskOld extends AsyncTask {

        ProgressDialog pDialog = null;

        String FromLocation,ToLocation,Rate,Weight,ArrivalTime,DepartureTime,Comments,TourDte,VehicleNo;

        StringBuilder sb=null;

        String sql;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(ViewMyTour.this);
            pDialog.setMessage("Fetching Data...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            sql =  getResources().getString(R.string.ip) + "/trans/ViewMyTour.php?Uid="+Uid;


        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL(sql);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();



            try {
                JSONObject jsonObj = new JSONObject(sb.toString());

                // Getting JSON Array node
                JSONArray dm = jsonObj.getJSONArray("data");

                // looping through All Contacts
                for (int i = 0; i < dm.length(); i++) {
                    JSONObject c = dm.getJSONObject(i);
                    //String vehicleNo, String rate, String weight, String date, String arrivalTime, String departureTime
                    String vehicleNo = c.getString("VehicleNo");
                    String rate = "Rs."+c.getString("Rate");
                    String weight ="Wt: "+ c.getString("MaxWeight");
                    String date = c.getString("Date");
                    String arrivalTime = "A: "+c.getString("ArrivalTime");
                    String departureTime = "D: "+c.getString("DepartureTime");
                    String Id =c.getString("Id");

                    dataModels.add(new DataModel(vehicleNo,rate,weight,date,arrivalTime,departureTime,Id));


                }
            } catch (JSONException e)
            {

            }

            adapter= new CustomAdapter(dataModels,getApplicationContext());
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    DataModel dataModel= dataModels.get(position);

                    //Snackbar.make(view, dataModel.getName()+"\n"+dataModel.getType()+" API: "+dataModel.getVersion_number(), Snackbar.LENGTH_LONG)
                    //      .setAction("No action", null).show();

                startActivity(new Intent(ViewMyTour.this,StartJourney.class).putExtra("id",dataModel.getId()));

                }
            });



        }

    }

}
