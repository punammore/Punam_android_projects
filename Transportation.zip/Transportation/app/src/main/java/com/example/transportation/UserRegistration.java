package com.example.transportation;

import android.app.ProgressDialog;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class UserRegistration extends AppCompatActivity {


    Button btnRegister;
EditText edtEmail, edtPwd,edtContact, edtFname;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_registration);

        btnRegister = findViewById(R.id.btnRegister);

        edtContact = findViewById(R.id.edtContact);
        edtEmail= findViewById(R.id.edtEmail);
        edtPwd = findViewById(R.id.edtPwd);
        edtFname = findViewById(R.id.edtFname);

        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                new MyTaskOld().execute();

               /* MyTask mt = new MyTask(wUrl,UserRegistration.this);

                mt.execute();


                Toast.makeText(UserRegistration.this, "RESULT: " + mt.getResponse(), Toast.LENGTH_SHORT).show();
*/
            }
        });

    }

    class MyTaskOld extends AsyncTask{

        ProgressDialog pDialog = null;

        String email,fname,pwd,contact;

        StringBuilder sb=null;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(UserRegistration.this);
            pDialog.setMessage("Fetching Data...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            email = edtEmail.getText().toString();
            pwd = edtPwd.getText().toString();
            contact = edtContact.getText().toString();
            fname = edtFname.getText().toString();

        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL( getResources().getString(R.string.ip) + "/trans/insert_record.php?email="+email + "&fname="+fname + "&password="+pwd + "&contactno=" + contact);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();

            Toast.makeText(UserRegistration.this, ""+sb, Toast.LENGTH_LONG).show();
        }
    }
}
