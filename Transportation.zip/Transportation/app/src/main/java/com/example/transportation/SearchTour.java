package com.example.transportation;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

public class SearchTour extends AppCompatActivity {

    ArrayList<DataModel> dataModels;
    ListView listView;
    CustomAdapter adapter;


    EditText edtFrom,edtTo;
    Button btnSubmit;
    String Uid,Tid;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_tour);
        edtFrom=findViewById(R.id.edtFrom);
        edtTo=findViewById(R.id.edtTo);
        btnSubmit=findViewById(R.id.btnSubmit);
        listView=findViewById(R.id.edtList);

        dataModels= new ArrayList<>();

        Uid=getIntent().getExtras().getString("Uid");
        Toast.makeText(SearchTour.this, "Uid"+ Uid, Toast.LENGTH_SHORT).show();

        btnSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dataModels.clear();
                new MyTaskOld().execute();

            }
        });
    }
    class MyTaskOld extends AsyncTask {

        ProgressDialog pDialog = null;

        String FromLocation,ToLocation;

        StringBuilder sb=null;

        String sql;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(SearchTour.this);
            pDialog.setMessage("Fetching Data...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            FromLocation = edtFrom.getText().toString();
            ToLocation = edtTo.getText().toString();
            sql =  getResources().getString(R.string.ip) + "/trans/Search_Tour.php?FromLocation="+FromLocation + "&ToLocation="+ToLocation;


        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL(sql);

                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();

            //Toast.makeText(SearchTour.this, ""+sb.toString(), Toast.LENGTH_LONG).show();

            try {
                JSONObject jsonObj = new JSONObject(sb.toString());

                // Getting JSON Array node
                JSONArray dm = jsonObj.getJSONArray("locs");

                // looping through All Contacts
                for (int i = 0; i < dm.length(); i++) {
                    JSONObject c = dm.getJSONObject(i);
                    //String vehicleNo, String rate, String weight, String date, String arrivalTime, String departureTime
                    String vehicleNo = c.getString("VehicleNo");
                    String rate = "Rs."+c.getString("Rate");
                    String weight ="Wt: "+ c.getString("MaxWeight");
                    String date = c.getString("Date");
                    String arrivalTime = "A: "+c.getString("ArrivalTime");
                    String departureTime = "D: "+c.getString("DepartureTime");
                    String Id =c.getString("Id");



                    dataModels.add(new DataModel(vehicleNo,rate,weight,date,arrivalTime,departureTime,Id));


                }
            } catch (JSONException e)
            {

            }

            adapter= new CustomAdapter(dataModels,getApplicationContext());
            listView.setAdapter(adapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                    DataModel dataModel= dataModels.get(position);
                    Tid=dataModel.getId();

                    DialogInterface.OnClickListener dialogClickListener = new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            switch (which){
                                case DialogInterface.BUTTON_POSITIVE:
                                    new MyTaskBook().execute();
                                    //Yes button clicked
                                    break;

                                case DialogInterface.BUTTON_NEGATIVE:
                                    //No button clicked
                                    break;
                            }
                        }
                    };

                    AlertDialog.Builder builder = new AlertDialog.Builder(SearchTour.this);
                    builder.setMessage("Are you sure want to book?").setPositiveButton("Yes", dialogClickListener)
                            .setNegativeButton("No", dialogClickListener).show();



                }
            });

        }
    }

    class MyTaskBook extends AsyncTask{

        ProgressDialog pDialog = null;

        String Surl="";

        StringBuilder sb=null;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();

            pDialog = new ProgressDialog(SearchTour.this);
            pDialog.setMessage("Booking Slot...");
            pDialog.setCancelable(false);
            pDialog.setIndeterminate(false);
            pDialog.show();

            Surl = getResources().getString(R.string.ip) + "/trans/BookSlot.php?Uid="+Uid + "&Tid="+Tid;

            Toast.makeText(SearchTour.this, ""+Surl, Toast.LENGTH_SHORT).show();

        }

        @Override
        protected Object doInBackground(Object[] objects) {


            BufferedReader reader=null;
            String serverResponse=null;
            try {

                URL url = new URL(Surl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            /*    connection.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
                connection.setConnectTimeout(5000);
                connection.setRequestMethod("GET");*/

                connection.connect();
                int statusCode = connection.getResponseCode();
                //Log.e("statusCode", "" + statusCode);
                if (statusCode == 200) {
                    sb = new StringBuilder();
                    reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    String line;
                    while ((line = reader.readLine()) != null) {
                        sb.append(line + "\n");
                    }
                }

                connection.disconnect();
                if (sb!=null)
                    serverResponse=sb.toString();
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (reader != null) {
                    try {
                        reader.close();
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            }




            return null;
        }

        @Override
        protected void onPostExecute(Object o) {
            super.onPostExecute(o);

            pDialog.dismiss();




            Toast.makeText(SearchTour.this, ""+sb, Toast.LENGTH_SHORT).show();

             /*   int output = Integer.parseInt(sb.toString());
                if (output > 0) {

                    Toast.makeText(SearchTour.this, "Slot Booked Successful" + output, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(SearchTour.this, "Sorry...Unable To Book Slot", Toast.LENGTH_SHORT).show();
                }*/
                 }
    }




}
